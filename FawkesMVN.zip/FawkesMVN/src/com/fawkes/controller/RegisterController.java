package com.fawkes.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fawkes.model.Register;

@Controller	
public class RegisterController {
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String getRegisterPage(){
		System.out.println("in register page");
		return "register";
	} 
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String registerUser(@ModelAttribute Register register,HttpSession session, HttpServletRequest request,
			ModelMap modelMap){
		System.out.println(register);
		String captcha = session.getAttribute("captcha_security").toString();
		String verifyCaptcha = request.getParameter("captcha");
		if (captcha.equals(verifyCaptcha)) {
			System.out.println("success");
			return "welcome";
		} else {
			System.out.println("not matched");
			return "notwelcome";
		}
		
	}
}
