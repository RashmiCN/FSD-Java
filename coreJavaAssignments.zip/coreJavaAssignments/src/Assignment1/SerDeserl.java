package Assignment1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class SerDeserl {
	
	public void SearchBook(String FileName, String bookName) throws FileNotFoundException {
		BufferedReader bookReader = new BufferedReader(new FileReader(FileName));
		Set<Book> bookSet = new TreeSet<Book>();
		String line;
		boolean bookFound = false;
		try {
			line = bookReader.readLine();
			while(line != null) {
				bookSet.add(new Book(line));
				System.out.println(line);
				line = bookReader.readLine();
			}
			bookReader.close();
			System.out.println("read done");
		} catch (IOException e) {
			e.printStackTrace();
			try {
				bookReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if(bookSet.size() > 0) {
			for(Book b : bookSet) {
				if(b.getTitle().equalsIgnoreCase(bookName)) {
					System.out.println("Book Found details below");
					System.out.println(b);
					bookFound = true;
				}
			}
			if(bookFound==false) {
				System.out.println("Book you are looking for isn't available");
			}
		}else {
		System.out.println("Nothing is there in file to read!");}
	}
	
	public void SearchSubject(String FileName, String subjectName) throws FileNotFoundException {
		BufferedReader subjectReader = new BufferedReader(new FileReader(FileName));
		ArrayList<Subject> subjectList = new ArrayList<Subject>();
		String line;
		boolean subjectFound = false;
		try {
			line = subjectReader.readLine();
			while(line != null) {
				subjectList.add(new Subject(line));
				System.out.println(line);
				line=subjectReader.readLine();
			}
			subjectReader.close();
			System.out.println("read done");
		} catch (IOException e) {
			e.printStackTrace();
			try {
				subjectReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if(subjectList.size() > 0) {
			for(Subject s : subjectList) {
				if(s.getSubtitle().equals(subjectName)) {
					System.out.println("subject Found details below");
					System.out.println(s);
					subjectFound = true;
				}
			}
			if(subjectFound==false) {
				System.out.println("subject you are looking for isn't available");
			}
		}else {
		System.out.println("Nothing is there in file to read!");}
	}
	public static void main(String[] args) throws IOException {
		SerDeserl sd = new SerDeserl();
		String filePathandName;
		String bookToSearch;
		String subjectToSearch;
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Do you want to search 'book' or 'subject' ");
		String typeofSearch = consoleReader.readLine();
		System.out.println("this is what you keyed in " + typeofSearch);
		System.out.println("Key in file name with path");
		filePathandName = consoleReader.readLine();
		System.out.println(filePathandName);
		System.out.println(typeofSearch);
		if(typeofSearch.equalsIgnoreCase("book")) {			
			System.out.println("key in book name you want to search");
			bookToSearch = consoleReader.readLine();
			sd.SearchBook(filePathandName, bookToSearch);
		}
		if(typeofSearch.equalsIgnoreCase("subject")) {
			System.out.println("key in subject name you want to search");
			subjectToSearch = consoleReader.readLine();
			sd.SearchSubject(filePathandName, subjectToSearch);
		}
	}
}
