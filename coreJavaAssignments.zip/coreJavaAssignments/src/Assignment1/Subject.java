package Assignment1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.TreeSet;

public class Subject {
	private long subjectId;
	private String subtitle;
	private int durationInHours;
	
	Set<Book> resources = new TreeSet<Book>();
	
	public long getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(long subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	public int getDurationInHours() {
		return durationInHours;
	}
	public Set<Book> getResources() {
		return resources;
	}
	public void setResources(Set<Book> resources) {
		this.resources = resources;
	}
	public void setDurationInHours(int durationInHours) {
		this.durationInHours = durationInHours;
	}
	
	public Subject() {
		super();
	}
	public Subject (String subjectCsvData) {
		String[] data = subjectCsvData.split(",");
		this.subjectId = Long.parseLong(data[0]);
		this.subtitle=data[1];
		this.durationInHours = Integer.parseInt(data[2]);
		int i = 3;
		
		System.out.println(i);
		do {	
			long bookid; 
			String title;
			double price;
			int volume; 
			LocalDate publishDate;
			
			bookid=Long.parseLong(data[i]); //3 +x = 8
			title= data[i+1]; //4
			price=Double.parseDouble(data[i+2]); //5
			volume =Integer.parseInt(data[i+3]); //6
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			publishDate = LocalDate.parse(data[i+4],formatter); //7
			
			Book b = new Book(bookid,title,price,volume,publishDate);
			this.resources.add(b);
			i+=5;
		}while(data[i].equals("end")!=true);
	}
	@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", subtitle=" + subtitle + ", durationInHours=" + durationInHours
				+ ", resources=" + resources + "]";
	}
	public Subject(long subjectId, String subtitle, int durationInHours) {
		super();
		this.subjectId = subjectId;
		this.subtitle = subtitle;
		this.durationInHours = durationInHours;
	}
	
}
