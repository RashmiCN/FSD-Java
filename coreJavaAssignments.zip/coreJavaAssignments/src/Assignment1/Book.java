package Assignment1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class Book implements Comparable<Book> {
	private long bookId; 
	private String title;
	private double price;
	private int volume; 
	private LocalDate publishDate;
	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public LocalDate getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(LocalDate publishDate) {
		this.publishDate = publishDate;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", price=" + price + ", volume=" + volume
				+ ", publishDate=" + publishDate + "]";
	}
	public Book(long bookId, String title, double price, int volume, LocalDate publishDate) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.price = price;
		this.volume = volume;
		this.publishDate = publishDate;
	}
	public Book(long bookId) {
		super();
		this.bookId = bookId;
	}
	public Book() {
		super();
	}
	public int compareTo(Book b) {
		System.out.println("the compare value is " + title.compareTo(b.title));
		System.out.println(title);
		System.out.println(b.getTitle());
		return title.compareTo(b.title);
	}
	
	
	public Book(String bookcsvdata) {
		String [] bookData = bookcsvdata.split(",");
		this.bookId=Long.parseLong(bookData[0]);
		this.title=bookData[1];
		this.price=Double.parseDouble(bookData[2]);
		this.volume=Integer.parseInt(bookData[3]);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		this.publishDate=LocalDate.parse(bookData[4], formatter);
	}
}
