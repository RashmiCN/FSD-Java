package Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RequestPrediction {
	private double startSal;
	private float incPer;
	private int  incFreq;
	private double deductions;
	private int deductFreq;
	private int predDurn;
	
	
	public RequestPrediction() {
		super();
	}

	
	@Override
	public String toString() {
		return "RequestPrediction [startSal=" + startSal + ", incPer=" + incPer + ", incFreq=" + incFreq
				+ ", deductions=" + deductions + ", deductFreq=" + deductFreq + ", predDurn=" + predDurn + "]";
	}


	public double getStartSal() {
		return startSal;
	}


	public void setStartSal(double startSal) {
		this.startSal = startSal;
	}


	public float getIncPer() {
		return incPer;
	}


	public void setIncPer(float incPer) {
		this.incPer = incPer;
	}


	public int getIncFreq() {
		return incFreq;
	}


	public void setIncFreq(int incFreq) {
		this.incFreq = incFreq;
	}


	public double getDeductions() {
		return deductions;
	}


	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}


	public int getDeductFreq() {
		return deductFreq;
	}


	public void setDeductFreq(int deductFreq) {
		this.deductFreq = deductFreq;
	}


	public int getPredDurn() {
		return predDurn;
	}


	public void setPredDurn(int predDurn) {
		this.predDurn = predDurn;
	}


	public RequestPrediction getUserdata() throws Exception{
		RequestPrediction rp = new RequestPrediction();
		BufferedReader readconsole = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please key in Starting Salary");
		double sal = 0;
		try {
			sal = Double.parseDouble(readconsole.readLine());
			System.out.println(sal);
		} catch (Exception e) {
			throw new PredictionException("Please key in valid Salary!", e);
		}
		if(sal == 0.0){
			throw new PredictionException("Salary cannot be Zero!");
		}
		return rp;
	}
	public static void main(String[] args) throws Exception  {
		RequestPrediction rp = new RequestPrediction();
		rp.getUserdata();
	}
	
	
}
