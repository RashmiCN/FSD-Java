package Assignment1;

public class PredictionException extends Exception {
	
	public PredictionException(String message, Exception e){
		super(message,e);
	}
	public PredictionException(String message){
		super(message);
	}
	
}
