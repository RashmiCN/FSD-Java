package Assignment1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SerDeserl {
	
	public List<Book> readBook(String Filename) throws FileNotFoundException {
		BufferedReader bookReader = new BufferedReader(new FileReader(Filename));
		List<Book> bookList = new ArrayList<Book>();
		String line;
		try {
			line = bookReader.readLine();
			while(line != null) {
				bookList.add(new Book(line));
				System.out.println(line);
				line = bookReader.readLine();
			}
			bookReader.close();
			System.out.println("read done");
		} catch (IOException e) {
			e.printStackTrace();
			try {
				bookReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return bookList;
	}
	
	public void SearchBook(List<Book> bookList,String bookName) {		
		boolean bookFound = false;
		if(bookList.size() > 0) {
			for(Book b : bookList) {
				if(b.getTitle().equalsIgnoreCase(bookName)) {
					System.out.println("Book Found details below");
					System.out.println(b);
					bookFound = true;
				}
			}
			if(bookFound==false) {
				System.out.println("Book you are looking for isn't available");
			}
		}else {
		System.out.println("Nothing is there in file to read!");}
	}
	
	public void addBook(String FileName) throws IOException {
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		Book b = new Book();
		System.out.println("book id");
		b.setBookId(Long.parseLong(consoleReader.readLine()));
		System.out.println("Book title");
		b.setTitle(consoleReader.readLine());
		System.out.println("price");
		b.setPrice(Double.parseDouble(consoleReader.readLine()));
		System.out.println("volume");
		b.setVolume(Integer.parseInt(consoleReader.readLine()));
		System.out.println("publish date");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		b.setPublishDate(LocalDate.parse(consoleReader.readLine(),formatter));
		
		try {
			FileOutputStream file = new FileOutputStream(FileName);
			ObjectOutputStream out = new ObjectOutputStream(file);
			out.writeObject(b);
			out.close();
			file.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public List<Subject> readSubject(String fileName) throws FileNotFoundException {
		BufferedReader subjectReader = new BufferedReader(new FileReader(fileName));
		ArrayList<Subject> subjectList = new ArrayList<Subject>();
		String line;
		try {
			line = subjectReader.readLine();
			while(line != null) {
				subjectList.add(new Subject(line));
				System.out.println(line);
				line=subjectReader.readLine();
			}
			subjectReader.close();
			System.out.println("read done");
		} catch (IOException e) {
			e.printStackTrace();
			try {
				subjectReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return subjectList;
	}

	public void SearchSubject(List<Subject> subjectList, String subjectName) throws FileNotFoundException {
		boolean subjectFound = false;
		if(subjectList.size() > 0) {
			for(Subject s : subjectList) {
				if(s.getSubtitle().equals(subjectName)) {
					System.out.println("subject Found details below");
					System.out.println(s);
					subjectFound = true;
				}
			}
			if(subjectFound==false) {
				System.out.println("subject you are looking for isn't available");
			}
		}else {
		System.out.println("Nothing is there in file to read!");}
	}
	
	public void addSubject(String FileName) throws IOException {
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		Subject s = new Subject();
		System.out.println("key in data as prompted");
		System.out.println("Subject id");
		s.setSubjectId(Long.parseLong(consoleReader.readLine()));
		System.out.println("Subject Title");
		s.setSubtitle(consoleReader.readLine());
		System.out.println("Duration in hours");
		s.setDurationInHours(Integer.parseInt(consoleReader.readLine()));		
		try {
			FileOutputStream file = new FileOutputStream(FileName);
			ObjectOutputStream out = new ObjectOutputStream(file);
			out.writeObject(s);
			out.close();
			file.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) throws IOException {
		SerDeserl sd = new SerDeserl();
		String filePathandName;
		String bookToSearch;
		String subjectToSearch;
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please key in one of the options below");
		System.out.println("'SearchSubject','SearchBook','AddBook','AddSubject','DelBook','DelSubject'");
		String typeofSearch = consoleReader.readLine();
		System.out.println("this is what you keyed in " + typeofSearch);
		System.out.println("Key in file name with path");
		filePathandName = consoleReader.readLine();
		System.out.println(filePathandName);
		
		if(typeofSearch.equalsIgnoreCase("SearchBook")) {	
			List<Book> bookArray = new ArrayList<Book>();
			bookArray = sd.readBook(filePathandName);
			System.out.println("key in book name you want to search");
			bookToSearch = consoleReader.readLine();
			sd.SearchBook(bookArray, bookToSearch);
		}
		if(typeofSearch.equalsIgnoreCase("SearchSubject")) {
			List<Subject> subArr= new ArrayList<Subject>();
			subArr = sd.readSubject(filePathandName);
			System.out.println("key in subject name you want to search");
			subjectToSearch = consoleReader.readLine();
			sd.SearchSubject(subArr, subjectToSearch);
		}
		if(typeofSearch.equals("AddBook")) {
			sd.addBook(filePathandName);
		}
		if(typeofSearch.equals("AddSubject")) {
			sd.addSubject(filePathandName);
		}
	}

	
}
