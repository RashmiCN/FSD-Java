import { PriorityFilterPipe } from './priority-filter.pipe';

describe('PriorityFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PriorityFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
