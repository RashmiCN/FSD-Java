import { ParentTaskFilterPipe } from './parent-task-filter.pipe';

describe('ParentTaskFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ParentTaskFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
