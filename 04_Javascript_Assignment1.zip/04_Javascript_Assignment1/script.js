function addProject(){
    document.getElementById("newproject").innerHTML+=document.getElementById("projectadd").value;
    return false;
    };


function addExperience(){
    document.getElementById("newexp").innerHTML+="<li>" + document.getElementById("expadd").value + "</li>";
    return false;
    }

function addQualification(){
    document.getElementById("newqual").innerHTML+="<li>" + document.getElementById("qualadd").value + "</li>";
    return false;
    }