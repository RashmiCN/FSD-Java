import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-highlights',
  templateUrl: './profile-highlights.component.html',
  styleUrls: ['./profile-highlights.component.css']
})
export class ProfileHighlightsComponent implements OnInit {
  profileHighlights = ["Joined Cognizant as a Fresher and went through training in Mainframe and Core Java. Worked as Developer in Retail sector and gained experience of 4.8 years.",
    "Gained exposure towards requirement gathering, analysis, design, coding and testing in compliance with standards and quality.",
    "Gained knowledge on various aspects of Retail industry",
    "Ability to resolve complex issues in short span of time.",
    "Mentored new entrants on business functionalities that helped them pickup project swiftly.",
    "Lead Team in Database CRUD migration project, first of its kind and ensured timely delivery in adherence to standardsand quality with zero post deployment defects.",
    "Participated in assessing the entire system to plan the phases to retire mainframe."]
  constructor() { }

  ngOnInit() {
  }

}
