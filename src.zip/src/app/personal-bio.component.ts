import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-bio',
  templateUrl: './personal-bio.component.html',
  styleUrls: ['./personal-bio.component.css']
})
export class PersonalBioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
