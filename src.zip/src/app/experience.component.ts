import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css']
})
export class ExperienceComponent implements OnInit {
  experience = ["Prepare proposals, estimations, timelines for projects and work requests.",
    "Analyzing the business requirements and design solutions for the same. ",
    "Development, Unit Testing in compliance with business requirements, SIT,standards and techniques to support task performance.",
    "Guide the team and ensure deliverables are prepared to satisfy project requirements in adherence to standards and quality and time.",
    "Mentor new entrants to pick up business functionalities, system processes to help them understand work requests better.",
    "Support various teams retiring and rewriting applications in open source languages."];
  constructor() { }

  ngOnInit() {
  }
  
  delExp(id : number):void {
      console.log("clicked");
      this.experience.splice(id,1);
      console.log(this.experience);
  };

  addExperience(value : string):void{
    console.log("clicked");
    console.log(value);
    this.experience.push(value);
  }

}
