import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {RouterModule} from '@angular/router';
import { ProfileHighlightsComponent } from './profile-highlights.component';
import { ExperienceComponent } from './experience.component';
import { ContactMeComponent } from './contact-me.component';
import { HomeComponent } from './home.component';
import { PersonalBioComponent } from './personal-bio.component';
import { ProjectsComponent } from './projects.component';

@NgModule({
  declarations: [
    AppComponent,
    ProfileHighlightsComponent,
    ExperienceComponent,
    ContactMeComponent,
    HomeComponent,
    PersonalBioComponent,
    ProjectsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path:'profile-highlights',component:ProfileHighlightsComponent},
      {path:'experience',component:ExperienceComponent},
      {path:'contact-me',component:ContactMeComponent},
      {path:'home',component:HomeComponent},
      {path:'personal-bio',component:PersonalBioComponent},
      {path:'projects',component:ProjectsComponent},
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
